#!/usr/bin/env bash
# Остановка Telegram Stars Bot
set -euo pipefail

cd "$(dirname "$0")"

export PATH="/Applications/Docker.app/Contents/Resources/bin:$HOME/.docker/bin:/opt/homebrew/bin:$PATH"

echo "🛑 Остановка контейнеров Docker..."
docker compose down

echo "🛑 Остановка туннеля cloudflared..."
pkill -f "cloudflared tunnel" || true

echo "✅ Бот и сервисы полностью остановлены."
