#!/bin/sh
export PATH=/usr/bin:/bin:/usr/sbin:/sbin

# Ensure directories and permissions
mkdir -p /run/postgresql /run/redis /tmp
chmod 777 /run/postgresql /run/redis /tmp

# 1. Start PostgreSQL if not already running
if ! LD_PRELOAD=/usr/lib/libshmem.so pg_isready -h 127.0.0.1 >/dev/null 2>&1; then
    echo "[run.sh] Starting PostgreSQL 16..."
    rm -f /run/postgresql/.s.PGSQL.* /var/lib/postgresql/data/postmaster.pid
    LD_PRELOAD=/usr/lib/libshmem.so su-exec postgres pg_ctl -D /var/lib/postgresql/data -l /var/lib/postgresql/data/logfile start
    
    # Wait for PostgreSQL to be ready
    for i in 1 2 3 4 5 6 7 8 9 10; do
        if LD_PRELOAD=/usr/lib/libshmem.so pg_isready -h 127.0.0.1 >/dev/null 2>&1; then
            echo "[run.sh] PostgreSQL is ready!"
            break
        fi
        sleep 1
    done
fi

# 2. Start Redis if not already running
if ! redis-cli ping >/dev/null 2>&1; then
    echo "[run.sh] Starting Redis server..."
    redis-server --daemonize yes
    for i in 1 2 3 4 5; do
        if redis-cli ping >/dev/null 2>&1; then
            echo "[run.sh] Redis is ready!"
            break
        fi
        sleep 1
    done
fi

cd /apps/stars-bot-liza

# 3. Ensure database and user exist
LD_PRELOAD=/usr/lib/libshmem.so psql -U postgres -h 127.0.0.1 -tc "SELECT 1 FROM pg_roles WHERE rolname='bot'" | grep -q 1 || LD_PRELOAD=/usr/lib/libshmem.so psql -U postgres -h 127.0.0.1 -c "CREATE USER bot WITH PASSWORD 'bot';"
LD_PRELOAD=/usr/lib/libshmem.so psql -U postgres -h 127.0.0.1 -tc "SELECT 1 FROM pg_database WHERE datname='wata_bot'" | grep -q 1 || LD_PRELOAD=/usr/lib/libshmem.so psql -U postgres -h 127.0.0.1 -c "CREATE DATABASE wata_bot OWNER bot;"

# 4. Run Alembic migrations
echo "[run.sh] Applying Alembic migrations..."
alembic upgrade head

# 5. Start Cloudflare tunnel for webhook if not active
if ! pgrep cloudflared >/dev/null 2>&1; then
    echo "[run.sh] Starting cloudflared tunnel..."
    cloudflared tunnel --url http://127.0.0.1:8090 > cloudflared.log 2>&1 &
fi

# Wait for tunnel URL
for i in 1 2 3 4 5 6 7 8 9 10; do
    TUNNEL_URL=$(grep -oE "https://[a-zA-Z0-9.-]+\.trycloudflare\.com" cloudflared.log 2>/dev/null | tail -n 1 | sed 's|https://||')
    if [ -n "$TUNNEL_URL" ]; then
        echo "[run.sh] Got tunnel host: $TUNNEL_URL"
        sed -i "s|^WEBHOOK_HOST=.*|WEBHOOK_HOST=$TUNNEL_URL|" .env
        break
    fi
    sleep 1
done

echo "[run.sh] Launching Telegram Stars Bot..."
export PYTHONUNBUFFERED=1
exec python3 -u -m app.main
