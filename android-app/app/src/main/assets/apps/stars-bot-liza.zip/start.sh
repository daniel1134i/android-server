#!/usr/bin/env bash
# Запуск Telegram Stars Bot в одну команду из терминала
set -euo pipefail

cd "$(dirname "$0")"

# Добавляем пути к Docker и утилитам
export PATH="/Applications/Docker.app/Contents/Resources/bin:$HOME/.docker/bin:/opt/homebrew/bin:$PATH"

echo "🚀 Проверка туннеля Cloudflare..."
if ! pgrep -f "cloudflared tunnel" >/dev/null; then
    echo "Запуск туннеля cloudflared..."
    nohup cloudflared tunnel --url http://127.0.0.1:8080 > cloudflared.log 2>&1 &
    sleep 3
    TUNNEL_URL=$(grep -oE "https://[a-zA-Z0-9.-]+\.trycloudflare\.com" cloudflared.log | tail -n 1 | sed 's|https://||')
    if [ -n "$TUNNEL_URL" ]; then
        echo "Новый адрес вебхука: $TUNNEL_URL"
        sed -i '' "s/^WEBHOOK_HOST=.*/WEBHOOK_HOST=$TUNNEL_URL/" .env
    fi
else
    echo "Туннель cloudflared уже активен."
fi

echo "🐳 Запуск контейнеров Docker (Postgres, Redis, Stars Bot)..."
docker compose up -d

echo "✅ Бот успешно запущен!"
echo "--------------------------------------------------------"
echo "Для остановки выполните: ./stop.sh"
echo "Ниже выводятся логи бота в реальном времени (Ctrl+C для выхода из логов):"
echo "--------------------------------------------------------"
docker compose logs -f bot
