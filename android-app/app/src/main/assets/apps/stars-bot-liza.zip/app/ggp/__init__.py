"""GreenGamePay (TON / crypto) Stars provider client."""
