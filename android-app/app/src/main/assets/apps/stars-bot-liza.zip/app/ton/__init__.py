"""TON blockchain scanning for the crypto (GreenGamePay) payment rail."""
