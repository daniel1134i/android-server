#!/usr/bin/env python3
import asyncio
import os
import re
from pyrogram import Client

API_ID = 6
API_HASH = "eb06d4abfb49dc3eeb1aeb9890f104d8"
SESSION_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "260677365"))

async def main():
    app = Client("260677365", api_id=API_ID, api_hash=API_HASH, workdir=os.path.dirname(SESSION_PATH))
    async with app:
        me = await app.get_me()
        print(f"Telegram Account: ID={me.id}, Username=@{me.username}, Name={me.first_name}")

        try:
            await app.unblock_user("BotFather")
        except Exception:
            pass

        await app.send_message("BotFather", "/cancel")
        await asyncio.sleep(2)
        mybots_msg = await app.send_message("BotFather", "/mybots")
        await asyncio.sleep(3)

        # Retrieve the latest message from BotFather
        async for msg in app.get_chat_history("BotFather", limit=5):
            if msg.from_user and msg.from_user.username == "BotFather":
                print(f"BotFather response: {msg.text}")
                if msg.reply_markup and hasattr(msg.reply_markup, "inline_keyboard"):
                    print("Found keyboard buttons:")
                    for row in msg.reply_markup.inline_keyboard:
                        for btn in row:
                            print(f" - {btn.text} -> {btn.callback_data}")
                break

if __name__ == "__main__":
    asyncio.run(main())
